Product: Nell Desk, August 2014
Designer: Guy Wolstenholme, guywolstenholme@me.com
Support:  support@obrary.com
Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Nell desk is designed to be printed on a CNC router.  A 1/4" end mill bit should be used on 18mm plywood.

Files included in this package:
 - 01_Nell_desk_back_side_struts.dwg
 - 02_Nell-desk_top-side.dwg
 - ReadMe.txt - this file